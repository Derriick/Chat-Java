/**
 * Package contenant les classes de l'interface graphique
 */
package widgets;
