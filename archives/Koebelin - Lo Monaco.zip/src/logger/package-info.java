/**
 * Classe contenant une factory permettant d'instancier plusieurs types de loggers
 * Un logger permet d'envoyer des messagde de logs (soit dans la console, soit
 * dans une fichier).
 * @author davidroussel
 */
package logger;