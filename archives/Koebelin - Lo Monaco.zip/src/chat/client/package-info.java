package chat.client;

/**
 * Sous-package contenant les classes relative à la partie client du
 * client/serveur de chat
 */
