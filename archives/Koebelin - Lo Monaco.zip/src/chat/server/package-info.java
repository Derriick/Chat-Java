package chat.server;

/**
 * Sous-package contenant les classes relatives à la partie serveur du
 * client/serveur de chat
 */
